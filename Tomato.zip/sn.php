﻿<?php
$form = $_POST["form"];
 echo ' <div style="display:none">'.$form.'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>';

?>